/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2024 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "esp.h"
#include "dht.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#ifdef __GNUC__
/* With GCC, small printf (option LD Linker->Libraries->Small printf
 set to 'Yes') calls __io_putchar() */
#define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
#define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */
#define ARR_CNT 5
#define CMD_SIZE 50

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart2;
UART_HandleTypeDef huart6;

/* USER CODE BEGIN PV */
uint8_t rx2char;
extern cb_data_t cb_data;
extern volatile unsigned char rx2Flag;
extern volatile char rx2Data[50];
volatile int tim3Flag1Sec = 1;
volatile unsigned int tim3Sec;
volatile uint8_t tim3Flag10Sec = 0;
volatile int keyNo;
volatile uint8_t sendFlag10Sec = 0; // 10초 타이머 플래그
int rgbFlag;
// 상태 저장용 전역 변수
int servo_angle = 0;
int door_servo_angle = 0;  // 문 서보모터 각도
int motor_state = 0;
int rgb_r = 0, rgb_g = 0, rgb_b = 0;

char strBuff[MAX_ESP_COMMAND_LEN];
void MX_GPIO_LED_ON(int flag);
void MX_GPIO_LED_OFF(int flag);
void esp_event(char*);
long map(long x, long in_min, long in_max, long out_min, long out_max);
void set_rgb_led(int red, int green, int blue);

DHT11_TypeDef dht11Data;
uint16_t light;
uint16_t CDS_Read(void);
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART6_UART_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
static void MX_ADC1_Init(void);
/* USER CODE BEGIN PFP */
char strBuff[MAX_ESP_COMMAND_LEN];
void MX_GPIO_LED_ON(int flag);
void MX_GPIO_LED_OFF(int flag);
void esp_event(char*);
long map(long x, long in_min, long in_max, long out_min, long out_max);
void set_rgb_led(int red, int green, int blue);
void control_devices_by_environment(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	int ret = 0;
//	DHT11_TypeDef dht11Data;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_USART6_UART_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */
	printf("Start main() - wifi\r\n");
	ret |= drv_uart_init();
	ret |= drv_esp_init();
	if (ret != 0) {
		printf("Esp response error\r\n");
		Error_Handler();
	}

	AiotClient_Init();

	DHT11_Init();

	if (HAL_TIM_Base_Start_IT(&htim3) != HAL_OK)
		Error_Handler();
	if (HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1) != HAL_OK)
		Error_Handler();
	if (HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2) != HAL_OK)
		Error_Handler();
	if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2) != HAL_OK)
		Error_Handler();
	if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3) != HAL_OK)
		Error_Handler();
	if (HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4) != HAL_OK)
		Error_Handler();

	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 500 - 1); // Servo 0도
	servo_angle = 0;
	__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 500 - 1); // Servo 0도
	door_servo_angle = 0;
	set_rgb_led(0, 0, 0); // RGB LED OFF
	rgb_r = rgb_g = rgb_b = 0;
	HAL_GPIO_WritePin(DCmotor_GPIO_Port, DCmotor_Pin, GPIO_PIN_RESET); // Motor OFF
	motor_state = 0;
	HAL_GPIO_WritePin(GPIOC, LED1_Pin, GPIO_PIN_RESET); // LED1 OFF
	HAL_GPIO_WritePin(GPIOC, LED2_Pin, GPIO_PIN_RESET); // LED2 OFF

	set_rgb_led(0, 0, 0);                                 // RGB LED OFF
	rgb_r = rgb_g = rgb_b = 0;

	HAL_GPIO_WritePin(DCmotor_GPIO_Port, DCmotor_Pin, GPIO_PIN_RESET); // DC Motor OFF
	motor_state = 0;

	HAL_GPIO_WritePin(GPIOC, LED1_Pin, GPIO_PIN_RESET);    // LED1 OFF
	HAL_GPIO_WritePin(GPIOC, LED2_Pin, GPIO_PIN_RESET);    // LED2 OFF
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {
		if (strstr((char*) cb_data.buf, "+IPD")
				&& cb_data.buf[cb_data.length - 1] == '\n') {
			strcpy(strBuff, strchr((char*) cb_data.buf, '['));
			memset(cb_data.buf, 0x0, sizeof(cb_data.buf));
			cb_data.length = 0;
			esp_event(strBuff);
		}

		if (rx2Flag) {
			printf("recv2 : %s\r\n", rx2Data);
			rx2Flag = 0;
		}
		if (sendFlag10Sec) {
			dht11Data = DHT11_readData();
			light = CDS_Read();
			control_devices_by_environment();
			sendFlag10Sec = 0;
		}

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.ScanConvMode = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure for the selected ADC regular channel its corresponding rank in the sequencer and its sample time.
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 84-1;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 1000-1;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 84-1;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 20000-1;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART6_UART_Init(void)
{

  /* USER CODE BEGIN USART6_Init 0 */

  /* USER CODE END USART6_Init 0 */

  /* USER CODE BEGIN USART6_Init 1 */

  /* USER CODE END USART6_Init 1 */
  huart6.Instance = USART6;
  huart6.Init.BaudRate = 38400;
  huart6.Init.WordLength = UART_WORDLENGTH_8B;
  huart6.Init.StopBits = UART_STOPBITS_1;
  huart6.Init.Parity = UART_PARITY_NONE;
  huart6.Init.Mode = UART_MODE_TX_RX;
  huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart6.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart6) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART6_Init 2 */

  /* USER CODE END USART6_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, LED1_Pin|LED2_Pin|DHT11_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|DCmotor_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LED1_Pin LED2_Pin DHT11_Pin */
  GPIO_InitStruct.Pin = LED1_Pin|LED2_Pin|DHT11_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin DCmotor_Pin */
  GPIO_InitStruct.Pin = LD2_Pin|DCmotor_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
// --- ADC (CDS 조도센서) 읽기 ---
uint16_t CDS_Read(void) {
	HAL_ADC_Start(&hadc1);
	if (HAL_ADC_PollForConversion(&hadc1, 100) == HAL_OK) {  // 100ms 타임아웃
		uint16_t adc_val = HAL_ADC_GetValue(&hadc1);
		HAL_ADC_Stop(&hadc1);
		return adc_val;
	} else {
		printf("CDS ADC Timeout Error\n");
		HAL_ADC_Stop(&hadc1);
		return 0xFFFF; // 실패값 리턴
	}

}

void send_status(void) {
	char status_buff[128];
	const char *led3_status =
			(rgb_r == 1000 && rgb_g == 1000 && rgb_b == 1000) ? "ON" : "OFF";
	const char *servo_status = (servo_angle == 90) ? "ON" : "OFF";
	const char *motor_status = (motor_state) ? "ON" : "OFF";

	sprintf(status_buff, "LED3: %s, SERVO: %s, MOTOR: %s", led3_status,
			servo_status, motor_status);
	printf("%s\r\n", status_buff);         // 시리얼 출력
	esp_send_data(status_buff);            // 서버로 전송
}

void esp_event(char *recvBuf) {
	int i = 0;
	char *pToken;
	char *pArray[5] = { 0 };  // 최대 5개 (ex: [USER_1]CAGE_CONTROL@1@LED@ON)
	char sendBuf[MAX_UART_COMMAND_LEN] = { 0 };

	strBuff[strlen(recvBuf) - 1] = '\0'; // 끝 개행 문자 삭제
	printf("\r\nDebug recv : %s\r\n", recvBuf);

	pToken = strtok(recvBuf, "[@]");
	while (pToken != NULL) {
		pArray[i] = pToken;
		if (++i >= 5)
			break;
		pToken = strtok(NULL, "[@]");
	}
	printf("1. %s\r\n", recvBuf);
	printf("2. %s\r\n", pArray[0]);
	printf("3. %s\r\n", pArray[1]);

	if (strcmp(pArray[1], "GET_SENSOR_DATA") == 0) {
		// DHT11 읽기 시도
		int try_count = 0;
		int max_retries = 3;
		do {
			dht11Data = DHT11_readData();
			if (dht11Data.rh_byte1 != 255) {
				break; // 성공
			}
			HAL_Delay(50); // 50ms 대기 후 재시도
		} while (++try_count < max_retries);

		if (dht11Data.rh_byte1 == 255) {
			printf("DHT11 Read Error after %d tries\n", max_retries);
			// 실패 데이터 전송 (서버에 오류 알림)
			sprintf(sendBuf,
					"[%s]GET_SENSOR_DATA@%s@ERROR@ERROR@ERROR@ERROR\r\n",
					pArray[0], pArray[2]);
			esp_send_data(sendBuf);
			return;
		}

		uint16_t light = CDS_Read();
		float light_percent = 0.0f;

		if (light == 0xFFFF) {
		    printf("CDS Sensor Read Error\n");
		    light_percent = -1.0f; // 에러 표시
		} else {
		    light_percent = (float)map(light, 0, 4095, 0, 100); // 0.0 ~ 100.0
		}

		printf("%s %s %s\r\n", pArray[0], pArray[1], pArray[2]);
		sprintf(sendBuf, "[%s]GET_SENSOR_DATA@%s@%d.%d@%d@%.2f\r\n", pArray[0],
				pArray[2], dht11Data.temp_byte1, dht11Data.temp_byte2,
				dht11Data.rh_byte1, light_percent);

		esp_send_data(sendBuf);
		printf("Send Sensor Data: %s\r\n", sendBuf);
	} else if (strcmp(pArray[1], "CAGE_CONTROL") == 0) {
		//책갈피2
		const char *win_state = (servo_angle == 90) ? "ON" : "OFF";
		const char *fan_state = (motor_state) ? "ON" : "OFF";
		const char *led_state =
				(rgb_r == 1000 && rgb_g ==1000 && rgb_b == 1000) ? "ON" : "OFF";

		const char *result = "SUCCESS";  // 기본값

		if (strcmp(pArray[3], "WIN") == 0) {
			if (strcmp(pArray[4], "ON") == 0) {
				__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 1500 - 1); // 90도
				servo_angle = 90;
			} else if (strcmp(pArray[4], "OFF") == 0) {
				__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 500 - 1); // 0도
				servo_angle = 0;
			} else {
				result = "FAILURE";
			}
		} else if (strcmp(pArray[3], "DOR") == 0) {
			if (strcmp(pArray[4], "ON") == 0) {
				__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 1500 - 1); // 90도
				door_servo_angle = 90;
			} else if (strcmp(pArray[4], "OFF") == 0) {
				__HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 500 - 1); // 0도
				door_servo_angle = 0;
			} else {
				result = "FAILURE";
			}
		} else if (strcmp(pArray[3], "FAN") == 0) {
			if (strcmp(pArray[4], "ON") == 0) {
				HAL_GPIO_WritePin(DCmotor_GPIO_Port, DCmotor_Pin, GPIO_PIN_SET);
				motor_state = 1;
			} else if (strcmp(pArray[4], "OFF") == 0) {
				HAL_GPIO_WritePin(DCmotor_GPIO_Port, DCmotor_Pin,
						GPIO_PIN_RESET);
				motor_state = 0;
			} else {
				result = "FAILURE";
			}
		} else if (strcmp(pArray[3], "LED") == 0) {
			if (strcmp(pArray[4], "ON") == 0) {
				set_rgb_led(1000, 1000, 1000); // 최대 밝기
				rgb_r = rgb_g = rgb_b = 1000;
			} else if (strcmp(pArray[4], "OFF") == 0) {
				set_rgb_led(0, 0, 0); // 끔
				rgb_r = rgb_g = rgb_b = 0;
			} else {
				result = "FAILURE";
			}
		} else {
			result = "FAILURE";
		}

		// CAGE_CONTROL 응답
		// [name]CAGE_CONTROL@cage_id@device@on or off
		sprintf(sendBuf, "[%s]CAGE_CONTROL@%s@%s@%s@%s", pArray[0], pArray[2],
				pArray[3], pArray[4], result);
		esp_send_data(sendBuf);

		// DB에 device data 저장
		// [DB]SET_CAGE_STATUS@cage_id@device@ON or OFF
		sprintf(sendBuf, "[DB]SET_CAGE_STATUS@%s@%s@%s", pArray[2], pArray[3], pArray[4]);
				esp_send_data(sendBuf);
		printf("Send Control Ack: %s\r\n", sendBuf);
	}
}

void control_devices_by_environment(void) {
    char sendBuf[MAX_UART_COMMAND_LEN];

    const char *win_state = (servo_angle == 90) ? "ON" : "OFF";
    const char *fan_state = (motor_state) ? "ON" : "OFF";
    const char *led_state = (rgb_r == 1000 && rgb_g == 1000 && rgb_b == 1000) ? "ON" : "OFF";

    // 조도 제어
    if (light < 500) {
        // LED ON
        set_rgb_led(1000, 1000, 1000);
        rgb_r = rgb_g = rgb_b = 1000;
        // DB 업데이트
        sprintf(sendBuf, "[DB]SET_CAGE_STATUS@%d@LED@ON\r\n", 1);
        esp_send_data(sendBuf);
        printf("LED ON due to low light (%d)\n", light);
    } else {
        // LED OFF
        set_rgb_led(0, 0, 0);
        rgb_r = rgb_g = rgb_b = 0;
        // DB 업데이트
        sprintf(sendBuf, "[DB]SET_CAGE_STATUS@%d@LED@OFF\r\n", 1);
        esp_send_data(sendBuf);
        printf("LED OFF due to sufficient light (%d)\n", light);
    }

    // 온도 제어
    if (dht11Data.temp_byte1 >= 26) {
        // 선풍기 ON
        HAL_GPIO_WritePin(DCmotor_GPIO_Port, DCmotor_Pin, GPIO_PIN_SET);
        motor_state = 1;
        // 창문 열기 (90도)
        __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 2500 - 1); // 90도
        servo_angle = 90;
        // DB 업데이트
        sprintf(sendBuf, "[DB]SET_CAGE_STATUS@%d@FAN@ON\r\n", 1);
        esp_send_data(sendBuf);
        sprintf(sendBuf, "[DB]SET_CAGE_STATUS@%d@WIN@ON\r\n", 1);
        esp_send_data(sendBuf);
        printf("FAN ON, Window OPEN due to high temp (%d°C)\n", dht11Data.temp_byte1);
    } else {
        // 선풍기 OFF
        HAL_GPIO_WritePin(DCmotor_GPIO_Port, DCmotor_Pin, GPIO_PIN_RESET);
        motor_state = 0;
        // 창문 닫기 (0도)
        __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 500 - 1); // 0도
        servo_angle = 0;
        // DB 업데이트
        sprintf(sendBuf, "[DB]SET_CAGE_STATUS@%d@FAN@OFF\r\n", 1);
        esp_send_data(sendBuf);
        sprintf(sendBuf, "[DB]SET_CAGE_STATUS@%d@WIN@OFF\r\n", 1);
        esp_send_data(sendBuf);
        printf("FAN OFF, Window CLOSED due to normal temp (%d°C)\n", dht11Data.temp_byte1);
    }

    // 센서 상태 전송
    if (dht11Data.rh_byte1 != 255) {
        sprintf(sendBuf, "[%d]CAGE_SENSOR_STATUS@%d@%s@%s@%s\r\n", 1, 1, win_state, fan_state, led_state);
        esp_send_data(sendBuf);
        printf("Send Sensor Status: %s\n", sendBuf);
    } else {
        sprintf(sendBuf, "[%d]CAGE_SENSOR_STATUS@%d@ERROR@ERROR@ERROR\r\n", 1, 1);
        esp_send_data(sendBuf);
        printf("DHT11 Read Error - skip sending sensor status.\n");
    }
}


void MX_GPIO_LED_ON(int pin) {
	HAL_GPIO_WritePin(LD2_GPIO_Port, pin, GPIO_PIN_SET);
}
void MX_GPIO_LED_OFF(int pin) {
	HAL_GPIO_WritePin(LD2_GPIO_Port, pin, GPIO_PIN_RESET);
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)		//1ms 마다 호출
{
	static int tim3Cnt = 0;
	tim3Cnt++;
	if (tim3Cnt >= 10000) //1ms * 10000 = 10Sec
			{
		tim3Flag10Sec = 1;
		tim3Cnt = 0;
	}
}
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
//	printf("EXTI %d\r\n",GPIO_Pin);
	switch (GPIO_Pin) {
	case GPIO_PIN_0:
		keyNo = 1;
		break;
	case GPIO_PIN_13:
		keyNo = 2;
		break;
	}
}
void set_rgb_led(int red, int green, int blue) {
	__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_2,(red-1)<0?0:red-1);
	__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_3,(green-1)<0?0:green-1);
	__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_4,(blue-1)<0?0:blue-1);
}
// --- 유틸리티 함수 ---
long map(long x, long in_min, long in_max, long out_min, long out_max) {
	return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();
	while (1) {
	}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
